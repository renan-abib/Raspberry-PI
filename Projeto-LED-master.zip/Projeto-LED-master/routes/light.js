var express = require('express');
var router = express.Router();
const Gpio = require("onoff").Gpio;

const led = new Gpio(4, 'out');

router.post('/lightOn', function(req, res, next) {
  led.writeSync(1);
});

router.post('/lightOff', function(req, res, next) {
  led.writeSync(0);
});

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Bem-vindo' });
});

module.exports = router;
